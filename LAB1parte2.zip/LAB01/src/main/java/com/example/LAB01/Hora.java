package com.example.LAB01;

public class Hora {
	private String hora;

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public Hora(String horaFormatada) {
		this.hora = horaFormatada;
	}

}
