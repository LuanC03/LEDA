package com.example.LAB01;

public class Greeting {
	private String nome;
	private String greeting;
	
	public Greeting(String nome, String greeting) {
		this.nome = nome;
		this.greeting = greeting;
	}

	public String getNome() {
		return this.nome;
	}
	public String getGreeting() {
		return this.greeting;
	}
}
