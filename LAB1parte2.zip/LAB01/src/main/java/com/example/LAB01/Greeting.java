package com.example.LAB01;

public class Greeting {
	private String nome;
	private String hora;
	
	public Greeting(String nome, String horaFormatada) {
		this.nome = nome;
		this.hora = horaFormatada;
	}

	public String nome() {
		return this.nome;
	}
	public String hora() {
		return this.hora;
	}
}
