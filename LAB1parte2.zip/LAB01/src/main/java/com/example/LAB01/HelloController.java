package com.example.LAB01;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HelloController {

	@RequestMapping("/greeting")
	public Greeting saudacao(@RequestParam(value = "name", defaultValue = "World") String name) {
		String greeting = getGreeting();
		return new Greeting(name, greeting);
	}
	@RequestMapping("/time")
	public Hora serverTime() {		
		return new Hora(getTimeServer());
	}
	
	private String getTimeServer() {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		return sdf.format(hora);
	}
	
	private String getGreeting() {
		String retorno;
		String[] hora = getTimeServer().split(":");
		int h = Integer.parseInt(hora[0]);
		if(h < 12) {
			retorno = "Bom Dia";
		}else if(h < 18) {
			retorno = "Boa Tarde";
		}else {
			retorno = "Boa Noite";
		}
		return retorno;
	}
}
