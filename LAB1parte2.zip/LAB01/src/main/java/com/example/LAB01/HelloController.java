package com.example.LAB01;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HelloController {

	@RequestMapping("/greeting")
	public Greeting saudacao(@RequestParam(value = "name", defaultValue = "World") String name) {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		String horaFormatada = sdf.format(hora);
		System.out.println(name);
		return new Greeting(name, horaFormatada);
	}
	@RequestMapping("/hora")
	public Hora hora() {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		String horaFormatada = sdf.format(hora);
		return new Hora(horaFormatada);
	}
}
